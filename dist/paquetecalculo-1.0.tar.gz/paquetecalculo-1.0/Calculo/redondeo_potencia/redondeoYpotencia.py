def potencia(base, exponente):
    print(
        f"El resultado de elevar {base} a la potencia {exponente} es: {base**exponente}")


def redondear(numero):
    print(f"El numero {numero} redondeado, es: {round(numero)}")
